<?php
die('x');
?>